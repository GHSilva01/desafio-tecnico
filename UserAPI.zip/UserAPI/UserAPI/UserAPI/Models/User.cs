﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations.Schema;

namespace UserAPI.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Email { get; set; }

        public string CPF { get; set; }

        public decimal Renda { get; set; }

        public string DtNasc { get; set; }

        public string Phone { get; set; }

        public string Job { get; set; }

    }
}
